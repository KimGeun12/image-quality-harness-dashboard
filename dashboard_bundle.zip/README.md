# 이미지 품질 Harness 대시보드

자체 Python Harness의 이미지 검사·변환·재시도·격리 기록과 CNN 결과를 확인하는 읽기 전용 대시보드입니다.

실행: `streamlit run dashboard.py`

Streamlit Community Cloud: Python 3.12, entrypoint `dashboard.py`.

전체 처리 로그 17,451장 및 Test 예측 3,742장 포함. 대표 이미지는 클래스/처리 분기 또는 예측 결과별 파일명 순서로 2장씩 선정한 48개 파일입니다. 이미지 출처는 실험에 사용한 Microsoft Cats vs Dogs 데이터입니다.

모델은 예측 기록과의 SHA-256 일치 검사에만 사용하며 서버에서 학습·추론하지 않습니다. 공개 manifest에서는 개인 PC 경로 열을 제거했고 원본/공개 사본 해시는 public_bundle.json에 구분했습니다.

정확도: Raw 81.03%, Harness 82.12%. 단일 실험이며 학습 데이터 수가 달라 정제만의 인과 효과로 단정할 수 없습니다.
