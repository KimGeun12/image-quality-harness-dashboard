"""Read-only monitoring of supplied Harness logs. No TensorFlow dependency."""
from __future__ import annotations
import csv
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'part3_harness'
VERIFY_COLUMNS = {'filename', 'issue', 'validation', 'retry_count', 'final_status', 'reason', 'output_path'}
ATTEMPT_COLUMNS = {'filename', 'attempt', 'agent', 'action', 'status', 'issues', 'metrics', 'reason'}
CONDITIONS = ['epochs', 'image_size', 'batch_size', 'seed', 'learning_rate', 'tensorflow',
              'model_source_hash', 'manifest_hash', 'val_hash', 'test_hash']

def read_csv(path, required=()):
    path = Path(path)
    if not path.exists():
        return [], False
    data = path.read_bytes()
    partial = bool(data and not data.endswith(b'\n'))
    if partial:
        data = data[:data.rfind(b'\n') + 1]
    reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig')))
    if not set(required).issubset(reader.fieldnames or []):
        raise ValueError(f'{path.name}: 필수 열이 없거나 헤더 작성 중입니다.')
    rows = list(reader)
    if any(None in r or any(v is None for v in r.values()) for r in rows):
        raise ValueError(f'{path.name}: 열 수가 맞지 않는 행이 있습니다.')
    return rows, partial

def read_json(path):
    path = Path(path)
    return json.loads(path.read_text(encoding='utf-8-sig')) if path.is_file() else None

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def safe_image(root, relative):
    """Never use source_path from the other PC, or trust absolute CSV paths."""
    root = Path(root).expanduser().resolve()
    rel = str(relative).replace('\\', '/')
    if ':' in rel or rel.startswith('/'):
        raise ValueError('이미지는 지정한 폴더의 상대 경로만 허용합니다.')
    path = (root / rel).resolve()
    if not path.is_relative_to(root):
        raise ValueError('이미지 경로가 지정한 폴더 밖을 가리킵니다.')
    return path

def aggregate(rows):
    names = [r['filename'] for r in rows]
    if len(names) != len(set(names)):
        raise ValueError('최종 로그에 같은 이미지가 중복 기록됐습니다.')
    if any(r['final_status'] not in {'SAVED','QUARANTINED'} or
           r['validation'] != ('PASS' if r['final_status']=='SAVED' else 'FAIL') for r in rows):
        raise ValueError('최종 상태와 검증 상태가 일치하지 않습니다.')
    retries = [int(r['retry_count']) for r in rows]
    if any(n < 0 for n in retries):
        raise ValueError('Retry 횟수가 음수입니다.')
    passed = [r for r in rows if r['final_status']=='SAVED']
    result = dict(total_images=len(rows), saved=len(passed), quarantined=len(rows)-len(passed),
        detected_images=sum(r['issue'] not in ('none','') for r in rows),
        first_pass=sum(int(r['retry_count'])==0 for r in passed),
        retry_images=sum(n>0 for n in retries), retry_pass=sum(int(r['retry_count'])>0 for r in passed),
        normal_saved=sum(r['issue']=='none' for r in passed))
    result['success_rate'] = result['saved']/len(rows) if rows else None
    return result

def snapshot(run_dir, data_dir):
    run, data = Path(run_dir), Path(data_dir)
    rows, pending = read_csv(run/'verification_log.csv', VERIFY_COLUMNS) if (run/'verification_log.csv').exists() else ([],False)
    totals = aggregate(rows)
    manifest, _ = read_csv(data/'dataset_manifest.csv')
    train = {f"{r['label']}/{r['filename']}" for r in manifest if r['split']=='train'}
    expected = len(train) if manifest else None
    summary = read_json(run/'summary.json')
    errors = []
    if train and not {r['filename'] for r in rows}.issubset(train):
        errors.append('Train manifest에 없는 이미지가 최종 로그에 있습니다.')
    config = read_json(run/'config.json')
    if config and any(int(r['retry_count'])>config['max_retries'] for r in rows):
        errors.append('설정한 Retry 한도를 초과했습니다.')
    if summary:
        for key, value in totals.items():
            if value is None or key not in summary or not math.isclose(float(value),float(summary[key]),abs_tol=1e-9):
                errors.append(f'summary와 로그의 {key} 값이 다릅니다.')
        if expected is not None and expected != len(rows):
            errors.append('완료 summary와 Train 예상 처리량이 다릅니다.')
    complete = bool(summary and not errors and not pending)
    state = '집계 불일치' if errors else ('완료 로그 확인' if complete else ('미완료 · 진행 중 또는 중단' if rows else '대기 · 로그 없음'))
    return dict(rows=rows, totals=totals, manifest=manifest, expected=expected,
                summary=summary, complete=complete, state=state, errors=errors, pending=pending,
                progress=(len(rows)/expected if expected else None), config=config)

def issue_counts(rows):
    counts = Counter()
    for row in rows:
        counts.update(set(x for x in row['issue'].split('|') if x and x!='none'))
    return dict(counts)

def compare_results(results_dir, snap, data_dir, code_dir=SOURCE):
    root=Path(results_dir)
    raw, clean = read_json(root/'raw_metrics.json'), read_json(root/'harness_metrics.json')
    errors=[]
    if not raw or not clean:
        return dict(available=False,errors=[],reason='두 모델의 학습 결과가 아직 없습니다.')
    for key in CONDITIONS:
        if key not in raw or key not in clean or raw[key]!=clean[key]:
            errors.append(f'A/B 조건 불일치: {key}')
    for name,m in [('Raw',raw),('Harness',clean)]:
        acc=m.get('test_accuracy')
        if not isinstance(acc,(int,float)) or not math.isfinite(acc) or not 0<=acc<=1:
            errors.append(f'{name} 정확도 범위 오류')
    if not snap['complete']:
        errors.append('완료된 Harness 집계를 확인할 수 없습니다.')
    if raw.get('train_count')!=snap['totals']['total_images'] or clean.get('train_count')!=snap['totals']['saved']:
        errors.append('학습 이미지 수와 처리 로그가 다릅니다.')
    for file,key in [(Path(data_dir)/'dataset_manifest.csv','manifest_hash'),(Path(code_dir)/'model.py','model_source_hash')]:
        expected_hash=raw.get(key)
        if key=='manifest_hash':
            provenance=read_json(ROOT/'public_bundle.json') or {}
            if provenance.get('original_manifest_sha256')!=expected_hash:
                errors.append('공개 manifest의 원본 연결 기록 불일치')
            expected_hash=provenance.get('public_manifest_sha256')
        if not file.exists() or digest(file)!=expected_hash:
            errors.append(f'전달 파일 해시 불일치 또는 누락: {file.name}')
    rows,_=read_csv(root/'comparison.csv')
    difference=100*(clean.get('test_accuracy',0)-raw.get('test_accuracy',0))
    if len(rows)!=1:
        errors.append('comparison.csv가 없거나 1행이 아닙니다.')
    else:
        checks={**snap['totals'],'raw_test_accuracy':raw['test_accuracy'],
                'harness_test_accuracy':clean['test_accuracy'],'accuracy_improvement_pp':difference}
        for key,value in checks.items():
            try:
                if value is None or not math.isclose(float(rows[0][key]),float(value),abs_tol=1e-9):
                    errors.append(f'comparison.csv 집계 불일치: {key}')
            except (KeyError,ValueError): errors.append(f'comparison.csv 형식 오류: {key}')
    return dict(available=not errors,errors=errors,raw=raw,harness=clean,difference_pp=difference,
                reason='전달 로그 기준 · 실제 재추론 여부는 예측 검증 기록에서 별도 확인')

def audit_attempts(rows, attempts, config):
    grouped=defaultdict(list)
    errors=[]
    for a in attempts:
        grouped[a['filename']].append(a)
        if a['status'] not in {'PASS','FAIL'} or a['action']=='error':continue
        try:
            m=json.loads(a['metrics'])
            expected=[]
            if m['width']<config['minimum_width'] or m['height']<config['minimum_height']:expected.append('low_resolution')
            if m['brightness']<config['brightness_threshold']:expected.append('dark')
            if m['blur']<config['blur_threshold']:expected.append('blur')
            if set(filter(None,a['issues'].split('|')))!=set(expected) or (a['status']=='PASS')!= (not expected):
                errors.append(f"기록된 측정값과 판정 불일치: {a['filename']}/{a['attempt']}")
        except (KeyError,ValueError,TypeError):errors.append(f"측정값 형식 오류: {a['filename']}")
    if set(grouped)!={r['filename'] for r in rows}:errors.append('최종/시도 로그의 이미지 집합 불일치')
    for r in rows:
        group=grouped[r['filename']]
        if not group:continue
        initial=[a for a in group if int(a['attempt'])==-1]
        processed=[a for a in group if int(a['attempt'])>=0]
        if len(initial)!=1 or initial[0]['issues']!=r['issue']:errors.append(f"최초 문제 불일치: {r['filename']}")
        if not processed:continue # unsupported issues may be quarantined directly
        if processed[-1]['status']!=r['validation'] or int(processed[-1]['attempt'])!=int(r['retry_count']):
            errors.append(f"최종 시도 불일치: {r['filename']}")
        if [int(a['attempt']) for a in processed] != list(range(int(r['retry_count'])+1)):
            errors.append(f"시도 순서 불일치: {r['filename']}")
        for previous,next_a in zip(processed,processed[1:]):
            if previous['status']!='FAIL':errors.append(f"PASS 뒤 불필요 Retry: {r['filename']}")
            action_map={'low_resolution':'resize','dark':'brightness_adjust','blur':'sharpen'}
            expected=[action_map.get(x,x) for x in previous['issues'].split('|') if x]
            if expected!=next_a['action'].split('+'):errors.append(f"남은 문제와 Retry 도구 불일치: {r['filename']}")
    return errors

def verified_predictions(path, results_dir, manifest):
    """Reject stale/mixed prediction artifacts before displaying test examples."""
    path,results=Path(path),Path(results_dir)
    if not path.is_file():return [],'Test 예측 파일이 없습니다.'
    proof=read_json(path.with_suffix('.verification.json'))
    if not proof:return [],'Test 예측 검증 파일이 없습니다.'
    if not isinstance(proof,dict):return [],'Test 예측 검증 기록의 형식이 잘못됐습니다. JSON 객체가 필요합니다.'
    if not isinstance(proof.get('model_sha256'),dict):return [],'모델 해시 기록의 형식이 잘못됐습니다. JSON 객체가 필요합니다.'
    if proof.get('csv_sha256')!=digest(path):return [],'예측 CSV가 검증 이후 변경됐습니다.'
    predictions,_=read_csv(path,{'filename','true_label','raw_prediction','harness_prediction','raw_dog_probability','harness_dog_probability'})
    expected={f"{r['label']}/{r['filename']}":r['label'] for r in manifest if r['split']=='test'}
    if len(predictions)!=len(expected) or {r['filename'] for r in predictions}!=set(expected):
        return [],'Test 예측과 현재 manifest가 다릅니다.'
    if proof.get('count')!=len(predictions):return [],'예측 검증 기록의 이미지 수가 다릅니다.'
    if any(r['true_label']!=expected[r['filename']] for r in predictions):return [],'Test 정답 레이블이 다릅니다.'
    for kind in ['raw','harness']:
        metric=read_json(results/f'{kind}_metrics.json')
        if not metric or proof.get('test_hash')!=metric.get('test_hash'):return [],'다른 Test의 예측입니다.'
        model=results/f'{kind}_model.keras'
        if not model.is_file() or proof.get('model_sha256',{}).get(kind)!=digest(model):return [],'다른 모델의 예측입니다.'
        for r in predictions:
            try:p=float(r[kind+'_dog_probability'])
            except (ValueError,TypeError):return [],'예측 확률 형식 오류'
            if not math.isfinite(p) or not 0<=p<=1:return [],'예측 확률 범위 오류'
            if r[kind+'_prediction']!=('dog' if p>0.5 else 'cat'):return [],'예측 레이블과 확률이 다릅니다.'
        actual=sum(r[kind+'_prediction']==r['true_label'] for r in predictions)/len(predictions)
        if not math.isclose(actual,metric['test_accuracy'],abs_tol=1e-6):return [],'예측 정확도가 전달 수치와 다릅니다.'
    return predictions,None
