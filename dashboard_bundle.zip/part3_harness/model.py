"""팀원 1 train_baseline.py와 동일한 모델 및 학습 설정."""
IMG_SIZE = (64, 64)
BATCH_SIZE = 32
EPOCHS = 5
SEED = 42
LEARNING_RATE = 0.001  # 팀원 1의 optimizer='adam' 기본 learning rate


def build_model():
    # A/B 모두 같은 함수에서 새 모델을 생성합니다. 기존 모델 가중치를 재사용하지 않습니다.
    import tensorflow as tf
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(*IMG_SIZE, 3)),
        tf.keras.layers.Rescaling(1.0 / 255),
        tf.keras.layers.Conv2D(32, 3, activation='relu'),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Conv2D(64, 3, activation='relu'),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Conv2D(128, 3, activation='relu'),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dropout(0.3),
        tf.keras.layers.Dense(1, activation='sigmoid'),
    ])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
                  loss='binary_crossentropy', metrics=['accuracy'])
    return model
